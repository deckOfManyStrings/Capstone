package model;

public class Customer {
    
    public int customerId;
    public String customerName;
    public int addressID;
    public String address;
    public int cityID;
    public String city;
    public String postalCode;
    public String phone;

    public Customer(int customerId, String customerName, int addressID, String address, int cityID, String city, String postalCode, String phone) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.addressID = addressID;
        this.address = address;
        this.cityID = cityID;
        this.city = city;
        this.postalCode = postalCode;
        this.phone = phone;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getAddressID() {
        return addressID;
    }

    public void setAddressID(int addressID) {
        this.addressID = addressID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getCityID() {
        return cityID;
    }

    public void setCityID(int cityID) {
        this.cityID = cityID;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
