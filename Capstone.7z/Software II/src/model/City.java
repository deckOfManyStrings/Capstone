package model;

public class City {
    
    private int cityId;
    private String city;
    
    public City(int cityId, String city) {
        this.cityId = cityId;
        this.city = city;
    }

    public int getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return city;
    }
    
}
