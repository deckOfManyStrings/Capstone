package views;
import Util.DBConnection;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import model.Appointment;

import java.awt.event.ActionEvent;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

public class reminderController implements Initializable {

    @FXML
    public Label reminderText;
    private ObservableList<Appointment> remAppointments = FXCollections.observableArrayList();
    public String customerId = customerController.viewCustomerId;

    public void handleOkayButton(javafx.event.ActionEvent actionEvent) {
        Platform.exit();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            //String appointmentId, String start, String end, String title, String description, Customer customer, String user
            PreparedStatement ps = DBConnection.getDbConnection().prepareStatement(
                    "SELECT appointment.appointmentId, appointment.customerId, appointment.title, appointment.description, "
                            + "appointment.`start`, appointment.`end`, customer.customerId, customer.customerName, appointment.createdBy "
                            + "FROM appointment, customer "
                            + "WHERE appointment.customerId = customer.customerId "
                            + "ORDER BY `start`");
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) {
                int appointmentId = rs.getInt("appointmentId");
                String customerName = rs.getString("customerName");
                String title = rs.getString("title");
                String description = rs.getString("description");
                LocalDateTime startDate = rs.getTimestamp("start").toLocalDateTime();
                LocalDateTime endDate = rs.getTimestamp("end").toLocalDateTime();

                remAppointments.add(new Appointment(appointmentId, customerName, title, description, startDate, endDate));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        LocalDateTime currentTime = LocalDateTime.now();
        LocalDateTime remTime = currentTime.plusMinutes(15);

        remAppointments.forEach(Appointment ->{
            if(Appointment.start.isAfter(currentTime) && Appointment.start.isBefore(remTime)){
                reminderText.setText(Appointment.title + "is starting soon.");
            }
        });
    }
}
