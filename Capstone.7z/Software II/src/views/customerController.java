package views;

import Util.DB.city;
import Util.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.City;
import java.io.FileReader;
import java.io.FileWriter;
import model.Customer;
import java.io.BufferedReader;
import java.util.Collections;
import java.util.List;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ResourceBundle;
import java.util.ArrayList;

public class customerController implements Initializable {

    public TableView CustomerTable;
    public TableColumn customerList;
    public TextField customerIDField;
    public TextField customerNameField;
    public TextField addressField;
    public TextField address2Field;
    public TextField postalCodeField;
    public TextField phoneField;

    private ObservableList<City> CityDropDown = city.getAllCities();
    private ObservableList<String> CountryDropDown = FXCollections.observableArrayList("US", "Canada", "Norway");
    private ObservableList<Customer> allCustomers = FXCollections.observableArrayList();


    String addCustomerID;
    String addCustomerName;
    String addCustomerAddress;
    String addCustomerAddress2;
    City addCustomerCity;
    String addCustomerCountry;
    String addCustomerPostalCode;
    String addCustomerPhone;

    SimpleDateFormat month = new SimpleDateFormat("MM");
    int jan = 0;
    int feb = 0;
    int mar = 0;
    int apr = 0;
    int may = 0;
    int jun = 0;
    int jul = 0;
    int aug = 0;
    int sep = 0;
    int oct = 0;
    int nov = 0;
    int dec = 0;

    public static String viewCustomerId;

    @FXML // fx:id="CountryDropdownSel"
    private ComboBox CountryDropdownSel; // Value injected by FXMLLoader

    @FXML // fx:id="CityDropdownSel"
    private ComboBox<City> CityDropdownSel; // Value injected by FXMLLoader

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //lamda
        CustomerTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                handleViewDetailsButton(null);
            }
        });
        CustomerTable.setItems(allCustomers);
        customerList.setCellValueFactory(new PropertyValueFactory<>("customerName"));

        //CityDropdownSel.setValue("City");
        CityDropdownSel.setItems(CityDropDown);

        clearCustomerList();
        updateCustomerList();

    }

    @FXML
    void handleViewDetailsButton(ActionEvent event) {
        Customer customerSel = (Customer)CustomerTable.getSelectionModel().getSelectedItem();
        if(customerSel == null){
            return;
        }

        customerIDField.setText(Integer.toString(customerSel.customerId));
        customerNameField.setText(customerSel.customerName);
        addressField.setText(customerSel.address);
        //walk through list, match id, set value
        for(City c: CityDropDown){
            if(c.getCityId() == customerSel.getCityID()){
                CityDropdownSel.setValue(c);
                break;
            }
        }
        postalCodeField.setText(customerSel.postalCode);
        phoneField.setText(customerSel.phone);

    }

    @FXML
    void handleGenerateReports(ActionEvent event) throws IOException, SQLException {
        //create number of appointment Types by month
        PrintWriter report1 = new PrintWriter("Report 1");
        PreparedStatement ps1 = DBConnection.getDbConnection().prepareStatement(
                "SELECT appointment.appointmentId, appointment.customerId, appointment.title, appointment.description, "
                        + "appointment.`start`, appointment.`end`, customer.customerId, customer.customerName, appointment.createdBy "
                        + "FROM appointment, customer "
                        + "WHERE appointment.customerId = customer.customerId "
                        + "ORDER BY `start`");
        ps1.execute();
        ResultSet rs1 = ps1.getResultSet();

        report1.println("Number of Appointments by Month");

        while (rs1.next()){
            LocalDateTime startDate = rs1.getTimestamp("start").toLocalDateTime();

            if (startDate.getMonth() == Month.JANUARY){
                jan++;
            } else if (startDate.getMonth() == Month.FEBRUARY){
                feb++;
            } else if (startDate.getMonth() == Month.MARCH){
                mar++;
            } else if (startDate.getMonth() == Month.APRIL){
                apr++;
            } else if (startDate.getMonth() == Month.MAY){
                may++;
            } else if (startDate.getMonth() == Month.JUNE){
                jun++;
            } else if (startDate.getMonth() == Month.JULY){
                jul++;
            } else if (startDate.getMonth() == Month.AUGUST){
                aug++;
            } else if (startDate.getMonth() == Month.SEPTEMBER){
                sep++;
            } else if (startDate.getMonth() == Month.OCTOBER){
                oct++;
            } else if (startDate.getMonth() == Month.NOVEMBER){
                nov++;
            } else if (startDate.getMonth() == Month.DECEMBER){
                dec++;
            }

        }

        report1.println("January" + " this year has " + jan + " Appointments");

        report1.println("February" + " this year has " + feb +" Appointments");

        report1.println("March" + " this year has " + mar +" Appointments");

        report1.println("April" + " this year has " + apr +" Appointments");

        report1.println("May" + " this year has " + may + " Appointments");

        report1.println("June" + " this year has " + jun +" Appointments");

        report1.println("July" + " this year has " + jul +" Appointments");

        report1.println("August" + " this year has " + aug +" Appointments");

        report1.println("September" + " this year has " + sep +" Appointments");

        report1.println("October" + " this year has " + oct +" Appointments");

        report1.println("November" + " this year has " + nov +" Appointments");

        report1.println("December" + " this year has " + dec +" Appointments");

        report1.close();

        //create schedule for each consultant
        PrintWriter report2 = new PrintWriter("Report 2");
        PreparedStatement ps2 = DBConnection.getDbConnection().prepareStatement("SELECT appointment.appointmentId, appointment.customerId, appointment.title, appointment.description, "
                + "appointment.`start`, appointment.`end`, customer.customerId, customer.customerName, appointment.createdBy "
                + "FROM appointment, customer "
                + "WHERE appointment.customerId = customer.customerId "
                + "ORDER BY `start`");
        ps2.execute();
        ResultSet rs2 = ps2.getResultSet();

        while (rs2.next()){
            String customerName = rs2.getString("customerName");
            if (customerName == ""){
                customerName = "No name Provided";
            }
            LocalDateTime startDate = rs2.getTimestamp("start").toLocalDateTime();
            LocalDateTime endDate = rs2.getTimestamp("end").toLocalDateTime();

            report2.println(customerName + " has an appointment starting at " + startDate + " and ending at " + endDate );
        }

        //Sort by Name
        String inputFile = "Report 2";
        String outputFile = "Report2sorted.txt";

        FileReader fileReader = new FileReader(inputFile);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String inputLine;
        List<String> lineList = new ArrayList<String>();
        while ((inputLine = bufferedReader.readLine()) != null) {
            lineList.add(inputLine);
        }

        fileReader.close();
        Collections.sort(lineList);

        FileWriter fileWriter = new FileWriter(outputFile);
        PrintWriter out = new PrintWriter(fileWriter);
        for (String outputLine : lineList) {
            out.println(outputLine);
        }
        out.flush();
        out.close();
        fileWriter.close();

        //create report of appointment for the month
        LocalDateTime monthRangeStart = LocalDateTime.now();
        LocalDateTime monthRangeEnd = monthRangeStart.plusDays(30);
        PrintWriter report3 = new PrintWriter("Report 3");
        report3.println("Appointments for this month");
        PreparedStatement ps3 = DBConnection.getDbConnection().prepareStatement(
                "SELECT appointment.appointmentId, appointment.customerId, appointment.title, appointment.description, "
                        + "appointment.`start`, appointment.`end`, customer.customerId, customer.customerName, appointment.createdBy "
                        + "FROM appointment, customer "
                        + "WHERE appointment.customerId = customer.customerId "
                        + "ORDER BY `start`");
        ps3.execute();
        ResultSet rs = ps3.getResultSet();

        while (rs.next()) {

            String title = rs.getString("title");
            LocalDateTime startDate = rs.getTimestamp("start").toLocalDateTime();
                if (startDate.isBefore(monthRangeEnd ) && startDate.isAfter(monthRangeStart)){
                    report3.println(title);

            }

        }
        report3.close();
    }

    @FXML
    void handleAddCustomerButton(ActionEvent event) {
        addCustomerID = customerIDField.getText();
        addCustomerName = customerNameField.getText();
        addCustomerAddress = addressField.getText();
        addCustomerCity = (City) CityDropdownSel.getValue();
        addCustomerPostalCode = postalCodeField.getText();
        addCustomerPhone = phoneField.getText();

        try {
            PreparedStatement psAddress = DBConnection.getDbConnection().prepareStatement("INSERT INTO address "
                    + "VALUES (NULL,?,?,?,?,?,NOW(),'BK',NOW(),'BK')", Statement.RETURN_GENERATED_KEYS);
            PreparedStatement ps = DBConnection.getDbConnection().prepareStatement("INSERT INTO customer "
                    + "VALUES (NULL,?,?,1,NOW(),'BK',NOW(),'BK')", Statement.RETURN_GENERATED_KEYS);

            psAddress.setString(1, addCustomerAddress);
            psAddress.setString(2,"");
            psAddress.setInt(3, addCustomerCity.getCityId());
            psAddress.setString(4, addCustomerPostalCode);
            psAddress.setString(5, addCustomerPhone);

            psAddress.execute();

            ResultSet rs = psAddress.getGeneratedKeys();
            rs.next();
            int addressID = rs.getInt(1);

            ps.setString(1, addCustomerName);
            ps.setInt(2, addressID );

            ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        clearCustomerList();
        updateCustomerList();

    }

    @FXML
    void handelDeleteCustomerButton(ActionEvent event) {
        Customer customerDel = (Customer)CustomerTable.getSelectionModel().getSelectedItem();
        if(customerDel == null){
            return;
        }

        try{
            PreparedStatement ps = DBConnection.getDbConnection().prepareStatement("DELETE customer.*, address.* from customer, address WHERE customer.customerId = ? AND customer.addressId = address.addressId");
            ps.setInt(1, customerDel.getCustomerId());
            ps.executeUpdate();

        } catch(SQLException e){
            e.printStackTrace();
        }

        clearCustomerList();
        updateCustomerList();

    }

    @FXML
    void handleUpdateCustomerButton(ActionEvent event) {
        Customer customerSel = (Customer)CustomerTable.getSelectionModel().getSelectedItem();
        if(customerSel == null){
            return;
        }

        //get update new customer info
        customerSel.customerId = Integer.parseInt(customerIDField.getText());
        customerSel.customerName = customerNameField.getText();
        customerSel.address = addressField.getText();
        customerSel.postalCode = postalCodeField.getText();
        customerSel.phone = phoneField.getText();

        addCustomerName = customerSel.customerName;
        addCustomerAddress = customerSel.address;
        addCustomerPhone = customerSel.phone;
        addCustomerPostalCode = customerSel.postalCode;

        City city = CityDropdownSel.getValue();


        try {
            PreparedStatement ps = DBConnection.getDbConnection().prepareStatement("UPDATE customer " +
                    " SET customerName = ? WHERE customerId = ?");
            ps.setString(1, addCustomerName);

            ps.setInt(2, customerSel.customerId);

            ps.executeUpdate();
            PreparedStatement ps1 = DBConnection.getDbConnection().prepareStatement("UPDATE address " +
                    " SET address = ?, phone = ?, postalCode = ?, cityId = ? WHERE addressId = ?");

            ps1.setString(1,addCustomerAddress);
            ps1.setString(2,addCustomerPhone);
            ps1.setString(3,addCustomerPostalCode);
            ps1.setInt(4, city.getCityId());
            ps1.setInt(5, customerSel.addressID);

            ps1.executeUpdate();

            //confirm row(s) effected
            if(ps.getUpdateCount() > 0)
                System.out.println(ps.getUpdateCount() + "row(s) affected");
            else
                System.out.println("No Change");

        } catch (SQLException e) {
            e.printStackTrace();
        }

        clearCustomerList();
        updateCustomerList();

    }


    @FXML
    void handleViewAppointmentsButton(ActionEvent event) throws IOException {

        //change scene
        Parent newRoot = FXMLLoader.load(getClass().getResource("appointment.fxml"));
        Stage newPrimaryStage = new Stage();
        newPrimaryStage = (Stage) loginController.getNewPrimaryStage();
        newPrimaryStage.setScene(new Scene(newRoot));
        newPrimaryStage.show();
    }

    private void updateCustomerList(){
        try {
            //String customerId, String customerName, int addressID, String address, int cityID, String city, String postalCode, String phone
            PreparedStatement ps = DBConnection.getDbConnection().prepareStatement(
                    "SELECT customer.customerId, customer.customerName, address.addressId, address.address, city.cityId, city.city, address.postalCode, address.phone " +
                            "FROM customer, address, city " +
                            "WHERE customer.addressId = address.addressId AND address.cityId = city.cityId " +
                            "ORDER BY customer.customerName");
            ps.execute();
            ResultSet rs = ps.getResultSet();


            while(rs.next()){
                int rsCustomerId = rs.getInt("customerId");
                String rsCustomerName = rs.getString("customerName");
                int rsAddessId = rs.getInt("addressId");
                String rsCustomerAddress = rs.getString("address");
                int rsCityId = rs.getInt("cityId");
                String rsCity = rs.getString("city");
                String rsPostalCode = rs.getString("postalCode");
                String rsCustomerPhone = rs.getString("phone");

                //String customerId, String customerName, int addressID, String address, int cityID, String city, String postalCode, String phone
                allCustomers.add(new Customer(rsCustomerId, rsCustomerName, rsAddessId, rsCustomerAddress, rsCityId,rsCity,rsPostalCode, rsCustomerPhone));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void clearCustomerList(){
        allCustomers.clear();
    }

    public String getViewCustomerId() {

        return viewCustomerId;
    }

    public void handleClearDetailsButton(ActionEvent actionEvent) {
        customerIDField.clear();
        customerNameField.clear();
        addressField.clear();
        postalCodeField.clear();
        phoneField.clear();
    }
}


