package views;

import Util.DBConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.User;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

import static javafx.fxml.FXMLLoader.load;

public class loginController {

    private static Stage newPrimaryStage;
    ResourceBundle rb = ResourceBundle.getBundle("lang", Locale.getDefault());
    User user = new User();

    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;
    @FXML
    private TextField usernameField;
    @FXML
    private Label titleText;
    @FXML
    private Label errorText;
    @FXML
    private Label passwordText;
    @FXML
    private Button signInButtonText;

    public static Stage getNewPrimaryStage() {
        return newPrimaryStage;
    }

    @FXML
    private Label usernameText;
    @FXML
    private PasswordField passwordField;


    public ResourceBundle getRb() {
        return rb;
    }

    public void setRb(ResourceBundle rb) {
        this.rb = rb;
    }

    public Label getTitleText() {
        return titleText;
    }

    public void setTitleText(Label titleText) {
        this.titleText = titleText;
    }

    public ResourceBundle getResources() {
        return resources;
    }

    public void setResources(ResourceBundle resources) {
        this.resources = resources;
    }

    public URL getLocation() {
        return location;
    }

    public void setLocation(URL location) {
        this.location = location;
    }

    public TextField getUsernameField() {
        return usernameField;
    }

    public void setUsernameField(TextField usernameField) {
        this.usernameField = usernameField;
    }

    public Label getErrorText() {
        return errorText;
    }

    public void setErrorText(Label errorText) {
        this.errorText = errorText;
    }

    public Label getPasswordText() {
        return passwordText;
    }

    public void setPasswordText(Label passwordText) {
        this.passwordText = passwordText;
    }

    public Label getUsernameText() {
        return usernameText;
    }

    public void setUsernameText(Label usernameText) {
        this.usernameText = usernameText;
    }

    public PasswordField getPasswordField() {
        return passwordField;
    }

    public void setPasswordField(PasswordField passwordField) {
        this.passwordField = passwordField;
    }

    public static User validUser;

    @FXML
    void handleSignInButton(ActionEvent event) throws IOException {
        String userName = usernameField.getText();  //Collect the input
        String password = passwordField.getText(); //Collect the input

        //logging data for logins
        Date date = new Date(System.currentTimeMillis());
        PrintWriter pw = new PrintWriter("User Login Log");
        pw.println(String.format(userName + " logged in at " + date));
        pw.close();

        if (userName.length() == 0 || password.length() == 0) {
            errorText.setText(rb.getString("empty"));
        } else {
            validUser = validateLogin(userName, password);
            if (validUser == null) {
                errorText.setText(rb.getString("incorrect"));
                return;
            } else {
                Parent newRoot = load(getClass().getResource("customer.fxml"));
                newPrimaryStage = new Stage();
                newPrimaryStage = (Stage) errorText.getScene().getWindow();
                newPrimaryStage.setScene(new Scene(newRoot));
                newPrimaryStage.show();
            }
        }

    }

    @FXML
    void initialize() {
        titleText.setText(rb.getString("title"));
        usernameText.setText(rb.getString("username"));
        passwordText.setText(rb.getString("password"));
        signInButtonText.setText(rb.getString("signin"));

    }

    User validateLogin(String username, String password) {
        try {
            PreparedStatement pst = DBConnection.getDbConnection().prepareStatement("SELECT * FROM user WHERE userName=? AND password=?");
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                user.setUsername(rs.getString("userName"));
                user.setPassword(rs.getString("password"));
                user.setUserID(rs.getInt("userId"));
            } else {
                return null;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

}
