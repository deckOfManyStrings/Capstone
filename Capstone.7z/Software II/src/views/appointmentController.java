package views;

import Util.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;
import model.Appointment;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;

import static javafx.fxml.FXMLLoader.load;

public class appointmentController implements Initializable {

    private final ObservableList<String> times = FXCollections.observableArrayList(
            "08:00", "09:00", "10:00", "11:00", "12:00",
            "13:00", "14:00", "15:00", "16:00");
    @FXML
    public TableColumn monthNameCol;
    public String customerId = customerController.viewCustomerId;
    @FXML
    public TableColumn weekNameCol;
    @FXML
    public TableColumn allNameCol;
    @FXML
    public TableColumn allNameId;

    DateTimeFormatter datePattern = DateTimeFormatter.ofPattern("HH:mm");

    @FXML
    private TableView monthsTableView;
    @FXML
    private TableView weeksTableView;
    @FXML
    private TableView allTableView;
    @FXML
    private TableColumn monthsTableColumn;
    @FXML
    private TableColumn weeksTableColumn;
    @FXML
    private ComboBox<String> startTime;
    @FXML
    private ComboBox<String> endTime;
    private ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();
    private ObservableList<Appointment> monthAppointments = FXCollections.observableArrayList();
    private ObservableList<Appointment> weekAppointments = FXCollections.observableArrayList();
    @FXML
    private TextField appointmentIDField;
    @FXML
    private TextField customerField;
    @FXML
    private TextField titleField;
    @FXML
    private TextField descriptionField;
    @FXML
    private DatePicker datePicker;

    boolean appSoon = false;

    private void updateAppointmentList() {
        try {
            //String appointmentId, String start, String end, String title, String description, Customer customer, String user
            PreparedStatement ps = DBConnection.getDbConnection().prepareStatement(
                    "SELECT appointment.appointmentId, appointment.customerId, appointment.title, appointment.description, "
                            + "appointment.`start`, appointment.`end`, customer.customerId, customer.customerName, appointment.createdBy "
                            + "FROM appointment, customer "
                            + "WHERE appointment.customerId = customer.customerId "
                            + "ORDER BY `start`");
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) {
                int appointmentId = rs.getInt("appointmentId");
                String customerName = rs.getString("customerName");
                String title = rs.getString("title");
                String description = rs.getString("description");
                LocalDateTime startDate = rs.getTimestamp("start").toLocalDateTime();
                LocalDateTime endDate = rs.getTimestamp("end").toLocalDateTime();

                allAppointments.add(new Appointment(appointmentId, customerName, title, description, startDate, endDate));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void handleViewDetailsButton(javafx.event.ActionEvent actionEvent) {
        Appointment appointment = (Appointment) monthsTableView.getSelectionModel().getSelectedItem();
        if (appointment == null) {
            return;
        }

        appointmentIDField.setText(Integer.toString(appointment.getAppointmentId()));
        customerField.setText(appointment.getCustomer());
        titleField.setText(appointment.getTitle());
        descriptionField.setText(appointment.getDescription());
        datePicker.setValue(appointment.getStart().toLocalDate());
        String st = datePattern.format(appointment.getStart().toLocalTime());
        startTime.setValue(st);
        String et = datePattern.format(appointment.getEnd().toLocalTime());
        endTime.setValue(et);

    }

    public void handleViewDetailsWeekly(ActionEvent actionEvent) {
        Appointment appointment = (Appointment) weeksTableView.getSelectionModel().getSelectedItem();
        if (appointment == null) {
            return;
        }

        appointmentIDField.setText(Integer.toString(appointment.getAppointmentId()));
        customerField.setText(customerId);
        titleField.setText(appointment.getTitle());
        descriptionField.setText(appointment.getDescription());
        datePicker.setValue(appointment.getStart().toLocalDate());
        String st = datePattern.format(appointment.getStart().toLocalTime());
        startTime.setValue(st);
        String et = datePattern.format(appointment.getEnd().toLocalTime());
        endTime.setValue(et);

    }

    public void handleAllDetails(ActionEvent actionEvent) {
        Appointment appointment = (Appointment) allTableView.getSelectionModel().getSelectedItem();
        if (appointment == null) {
            return;
        }

        appointmentIDField.setText(Integer.toString(appointment.getAppointmentId()));
        customerField.setText(customerId);
        titleField.setText(appointment.getTitle());
        descriptionField.setText(appointment.getDescription());
        datePicker.setValue(appointment.getStart().toLocalDate());
        String st = datePattern.format(appointment.getStart().toLocalTime());
        startTime.setValue(st);
        String et = datePattern.format(appointment.getEnd().toLocalTime());
        endTime.setValue(et);

    }

    public void handleAddButton(ActionEvent actionEvent) {
        int madeUpUser = 10;
        Timestamp trueStartTime = Timestamp.valueOf(LocalDateTime.of(datePicker.getValue(), LocalTime.parse(startTime.getValue())));
        Timestamp trueEndTime = Timestamp.valueOf(LocalDateTime.of(datePicker.getValue(), LocalTime.parse(endTime.getValue())));
        LocalTime lt = LocalTime.parse(startTime.getValue(), datePattern);
        System.out.println(lt);
        addUserCount(madeUpUser);
        boolean okayToAdd = true;

        try {
            PreparedStatement ps = DBConnection.getDbConnection().prepareStatement(
                    "SELECT appointment.appointmentId, appointment.customerId, appointment.title, appointment.description, "
                            + "appointment.`start`, appointment.`end`, customer.customerId, customer.customerName, appointment.createdBy "
                            + "FROM appointment, customer "
                            + "WHERE appointment.customerId = customer.customerId "
                            + "ORDER BY `start`");
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) {
                //checking if appointments overlap
                LocalDateTime startDate = rs.getTimestamp("start").toLocalDateTime();
                LocalDateTime endDate = rs.getTimestamp("end").toLocalDateTime();

                if (trueStartTime.toLocalDateTime().isBefore(startDate) && endDate.isBefore(trueEndTime.toLocalDateTime()) ){
                    okayToAdd = false;
                }

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(okayToAdd == true){
            try {
                PreparedStatement psAppointment = DBConnection.getDbConnection().prepareStatement(
                        "INSERT INTO appointment " + "VALUES (NULL, ?, ?, ?, ?, ' ', ?, ' ', ' ', ?, ?, NOW(), 'BK', NOW(), 'BK') ");
                psAppointment.setInt(1, Integer.parseInt(customerField.getText()));
                psAppointment.setInt(2, loginController.validUser.getUserID());
                psAppointment.setString(3, titleField.getText());
                psAppointment.setString(4, descriptionField.getText());
                psAppointment.setString(5, customerField.getText());
                psAppointment.setTimestamp(6, trueStartTime);
                psAppointment.setTimestamp(7, trueEndTime);

                psAppointment.execute();

                //confirm row(s) effected
                if(psAppointment.getUpdateCount() > 0)
                    System.out.println(psAppointment.getUpdateCount() + "row(s) affected");
                else
                    System.out.println("No Change");

            } catch (SQLException e) {
                e.printStackTrace();
            }

            clearAppointmentsList();
            updateAppointmentList();
        }else{
            System.out.println("Appointment Overlap. Appointment not added");
        }



    }

    public void handleDeleteButton(ActionEvent actionEvent) {
        Appointment appointmentDel = (Appointment)allTableView.getSelectionModel().getSelectedItem();
        if (appointmentDel == null){
            appointmentDel = (Appointment)monthsTableView.getSelectionModel().getSelectedItem();
            if (appointmentDel == null){
                appointmentDel = (Appointment)weeksTableView.getSelectionModel().getSelectedItem();
            }
        }

        try{
            PreparedStatement pst = DBConnection.getDbConnection().prepareStatement("DELETE FROM appointment WHERE appointment.appointmentId = ?");
            pst.setInt(1, appointmentDel.getAppointmentId());
            pst.executeUpdate();

        } catch(SQLException e){
            e.printStackTrace();
        }

        clearAppointmentsList();
        updateAppointmentList();
    }

    public void handleUpdateButton(ActionEvent actionEvent) {
        LocalTime lt = LocalTime.parse(startTime.getValue(), datePattern);
        System.out.println(lt);
        Appointment appointment = (Appointment) allTableView.getSelectionModel().getSelectedItem();
        if (appointment == null) {
            return;
        }

        appointment.description = descriptionField.getText();
        appointment.title = titleField.getText();
        appointment.start = LocalDateTime.of(datePicker.getValue(), LocalTime.parse(startTime.getValue(),datePattern));
        appointment.end = LocalDateTime.of(datePicker.getValue(), LocalTime.parse(endTime.getValue(),datePattern));

        try {
            PreparedStatement psUpdate = DBConnection.getDbConnection().prepareStatement(
                    "UPDATE appointment " + "SET title = ?, description = ?, start = ?, end = ? " +
                            "WHERE appointmentId = ?");
            psUpdate.setString(1, titleField.getText());
            psUpdate.setString(2,descriptionField.getText());
            psUpdate.setTimestamp(3, Timestamp.valueOf(appointment.start));
            psUpdate.setTimestamp(4, Timestamp.valueOf(appointment.end));
            psUpdate.setInt(5,appointment.getAppointmentId());


            psUpdate.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        clearAppointmentsList();
        updateAppointmentList();

    }

    public void handleSignoutButton(ActionEvent actionEvent) throws IOException {
        //change scene
        Parent newRoot = FXMLLoader.load(getClass().getResource("customer.fxml"));
        Stage newPrimaryStage = new Stage();
        newPrimaryStage = (Stage) loginController.getNewPrimaryStage();
        newPrimaryStage.setScene(new Scene(newRoot));
        newPrimaryStage.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        updateAppointmentList();
        //lamda
        monthsTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                handleViewDetailsButton(null);
            }
        });
        weeksTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                handleViewDetailsWeekly(null);
            }
        });
        allTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                handleAllDetails(null);
            }
        });

        allTableView.setItems(allAppointments);


        //set appointments for the month
        LocalDateTime monthRangeStart = LocalDateTime.now();
        LocalDateTime monthRangeEnd = monthRangeStart.plusDays(30);
        for ( Appointment app : allAppointments) {
            if (app.start.isBefore(monthRangeEnd) && app.start.isAfter(monthRangeStart) ){
                monthAppointments.add(app);
            }
        }
        monthsTableView.setItems(monthAppointments);
        //set appointments for the week
        LocalDateTime weekRangeStart = LocalDateTime.now();
        LocalDateTime weekRangeEnd = weekRangeStart.plusDays(7);
        for ( Appointment app : allAppointments ) {
            if (app.start.isBefore(weekRangeEnd ) && app.start.isAfter(weekRangeStart)){
                weekAppointments.add(app);
            }
        }
        weeksTableView.setItems(weekAppointments);

        monthsTableColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        weeksTableColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        allNameId.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));

        allNameCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        monthNameCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        weekNameCol.setCellValueFactory(new PropertyValueFactory<>("description"));

        startTime.setItems(times);
        startTime.setValue("Start Time");
        endTime.setItems(times);
        endTime.setValue("End Time");

        clearAppointmentsList();
        updateAppointmentList();
        appReminder();

        if (appSoon == true){
            Parent newRoot = null;
            try {
                newRoot = load(getClass().getResource("reminder.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            Stage newPrimaryStage = new Stage();
            newPrimaryStage.setScene(new Scene(newRoot));
            newPrimaryStage.show();
        }
    }

    public void handleClearDetailsButton(ActionEvent actionEvent) {
        appointmentIDField.clear();
        customerField.clear();
        titleField.clear();
        descriptionField.clear();

    }

    public void handleClearDetailsMonth(ActionEvent actionEvent) {
        appointmentIDField.clear();
        customerField.clear();
        titleField.clear();
        descriptionField.clear();
    }

    public void handleClearDetailsWeekly(ActionEvent actionEvent) {
        appointmentIDField.clear();
        customerField.clear();
        titleField.clear();
        descriptionField.clear();
    }

    public void clearAppointmentsList(){
        allAppointments.clear();
    }

    public int addUserCount(int user){
        return user++;
    }

    public void appReminder(){
        LocalDateTime currentTime = LocalDateTime.now();
        LocalDateTime remTime = currentTime.plusMinutes(15);

        allAppointments.forEach(Appointment ->{
            if(Appointment.start.isAfter(currentTime) && Appointment.start.isBefore(remTime)){
                appSoon = true;
            }
        });
    }
}
