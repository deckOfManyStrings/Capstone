package views;

import Util.DBConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;


public class Main extends Application {
    static Parent root;

    @Override
    public void start(Stage primaryStage) throws Exception{
        primaryStage.setTitle("Calendar App");
        showLogin(primaryStage);

    }


    public static void main(String[] args) {
        Connection connection = DBConnection.getDbConnection();
        DBConnection.connectDB();
        launch(args);
        DBConnection.disconnect();

    }

    public void showLogin(Stage primaryStage) throws IOException {
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public static void hideStage(Stage primaryStage){
        primaryStage.hide();
    }
}

