package Util.DB;

import Util.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.City;
import model.Customer;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class city {

    public static ObservableList<City> getAllCities(){
        ObservableList<City> cityList = FXCollections.observableArrayList();
        PreparedStatement ps;

        try {
            ps = DBConnection.getDbConnection().prepareStatement(
                    "SELECT * FROM city");
            ps.execute();
            ResultSet rs = ps.getResultSet();
            while(rs.next()){
                int rsCityId = rs.getInt("cityId");
                String rsCity = rs.getString("city");
                cityList.add(new City(rsCityId,rsCity));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        ; return cityList;
    }
}
